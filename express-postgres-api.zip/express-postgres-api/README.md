# Express + PostgreSQL CRUD API

A simple RESTful API built with **Express.js** and **PostgreSQL** that supports full CRUD operations for a `users` table.

## Features
- GET all users
- GET a user by ID
- POST create a new user
- PUT update an existing user
- DELETE a user by ID

## Technologies
- Node.js
- Express.js
- PostgreSQL
- pg (PostgreSQL client)
- dotenv

## Database Setup
Run this SQL to create the required table:
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  age INTEGER
);
```

## Environment Variables
Create a `.env` file in the root directory:
```
DB_USER=your_username
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=your_database
PORT=3000
```

## Running the App

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. Use Postman to test the endpoints at `http://localhost:3000/users`

## Endpoints

| Method | Route           | Description            |
|--------|------------------|------------------------|
| GET    | `/users`         | Get all users          |
| GET    | `/users/:id`     | Get user by ID         |
| POST   | `/users`         | Create a new user      |
| PUT    | `/users/:id`     | Update existing user   |
| DELETE | `/users/:id`     | Delete user by ID      |

---

## License
MIT
